//*************   © Copyrighted by Thinkcreative_Technologies. An Exclusive item of Envato market. Make sure you have purchased a Regular License OR Extended license for the Source Code from Envato to use this product. See the License Defination attached with source code. *********************

// ignore: todo
////TODO WARNING:    DO NOT EDIT THIS PAGE UNLESS YOU ARE A DEVELOPER. THIS PAGE HAS ALL THE KEYS USED IN FIRESTORE & FIREBASE TORAGEDATABASE -----

class DbPaths {
  static final String collectionTXNHIGHalerts = 'txnalerts';
  static final String collectionALLNORMALalerts = 'nmlalerts';

  static final String collectiondashboard = 'dashboard';
  static final String collectioncountrywiseData = 'countrywisedata';

  static final String docchatdata = 'chatdata';
  static final String docuserscount = 'userscount';

  static final String collectionusers = 'users';
  static final String collectiontemptokensforunsubscribe =
      'tempUnsubscribeTokens';
  static final String collectionmessages = 'messages';
  static final String collectioncall = 'call';
  static final String collectioncallhistory = 'callhistory';

  static final String collectionnotifications = 'notifications';
  static final String adminnotifications = 'adminnotifications';
  static final String usersnotifications = 'usersnotifications';
  static final String collectionhistory = 'history';
  static final String collectionnstatus = 'status';
  static final String collectiongroups = 'groups';

  static final String collectiongroupChats = 'groupChats';
  static final String collectionbroadcasts = 'broadcasts';
  static final String collectionbroadcastsChats = 'broadcastChats';
}
